# AI Vector Cache - 向量检索与智能缓存服务平台

一个轻量级的向量检索与智能缓存服务平台，借鉴 RedisVL 的设计理念，使用 Redis + Faiss 作为底层存储与检索引擎。

## 特性

- 🚀 **快速向量检索**: 基于 Faiss 的高性能向量相似度搜索
- 📦 **语义缓存**: 基于向量相似度的 LLM 查询缓存，减少重复调用
- 💾 **嵌入缓存**: 缓存文本嵌入结果，避免重复计算
- 💬 **语义消息历史**: 支持按时间和语义相似度检索对话历史
- 🗺️ **语义路由**: 基于语义相似度的查询路由
- 🔌 **可扩展**: 模块化设计，易于扩展自定义功能

## 项目结构

```
week17/
├── ai_vector_cache/
│   ├── __init__.py          # 包入口，导出公共 API
│   ├── vectorizer.py        # 向量化接口和实现
│   ├── storage.py           # 向量存储（Faiss + Redis）
│   ├── cache.py             # 缓存实现（语义缓存 + 嵌入缓存）
│   ├── message_history.py   # 语义消息历史
│   ├── router.py            # 语义路由
│   └── utils.py             # 工具函数
├── examples/
│   ├── basic_usage.py       # 基础使用示例
│   └── performance_test.py  # 性能测试脚本
├── tests/
│   └── test_basic.py        # 单元测试
├── pyproject.toml           # 项目配置
└── requirements.txt         # 依赖列表
```

## 快速开始

### 安装依赖

```bash
pip install -r requirements.txt
```

或使用开发模式安装：

```bash
pip install -e .
```

### 基础使用

#### 1. 向量化

```python
from ai_vector_cache import SentenceTransformerVectorizer

# 初始化向量器
vectorizer = SentenceTransformerVectorizer(model_name="sentence-transformers/all-MiniLM-L6-v2")

# 单个文本向量化
embedding = vectorizer.embed("Hello, world!")
print(f"Embedding shape: {embedding.shape}")

# 批量向量化
embeddings = vectorizer.embed_many(["Hello!", "How are you?"])
```

#### 2. 语义缓存

```python
from ai_vector_cache import SentenceTransformerVectorizer, FaissStorage, SemanticCache

vectorizer = SentenceTransformerVectorizer()
storage = FaissStorage(dimension=vectorizer.dimension)

# 初始化语义缓存
cache = SemanticCache(
    vectorizer=vectorizer,
    vector_storage=storage,
    similarity_threshold=0.7,
    default_ttl=3600  # 1小时过期
)

# 存储查询和响应
cache.set("What is the capital of France?", "Paris")

# 查询缓存（支持语义相似查询）
response = cache.get("What's France's capital city?")
print(f"Cache response: {response}")
```

#### 3. 嵌入缓存

```python
from ai_vector_cache import SentenceTransformerVectorizer, CachedVectorizer

# 使用带缓存的向量器
base_vectorizer = SentenceTransformerVectorizer()
cached_vectorizer = CachedVectorizer(base_vectorizer)

# 第一次调用会计算并缓存
embedding1 = cached_vectorizer.embed("Hello world")

# 第二次调用直接从缓存读取
embedding2 = cached_vectorizer.embed("Hello world")

assert embedding1 is not None and embedding2 is not None
```

#### 4. 语义消息历史

```python
from ai_vector_cache import SentenceTransformerVectorizer, FaissStorage, SemanticMessageHistory

vectorizer = SentenceTransformerVectorizer()
storage = FaissStorage(dimension=vectorizer.dimension)

history = SemanticMessageHistory(vectorizer=vectorizer, vector_storage=storage)

# 添加消息
history.add_message("user", "Hello, how are you?")
history.add_message("assistant", "I'm fine, thank you!")
history.add_message("user", "What's the weather today?")

# 获取最近消息
recent = history.get_recent(2)
print("Recent messages:", recent)

# 按语义检索
similar = history.search_similar("Hi there!", top_k=2)
print("Similar messages:", similar)
```

#### 5. 语义路由

```python
from ai_vector_cache import SentenceTransformerVectorizer, FaissStorage, SemanticRouter, Route

vectorizer = SentenceTransformerVectorizer()
storage = FaissStorage(dimension=vectorizer.dimension)

router = SemanticRouter(vectorizer=vectorizer, vector_storage=storage)

# 添加路由规则
router.add_route(Route(
    name="weather",
    examples=["What's the weather?", "Is it raining?", "Temperature"],
    metadata={"type": "weather"}
))
router.add_route(Route(
    name="coding",
    examples=["How to code Python?", "Debug my program"],
    metadata={"type": "coding"}
))

# 路由查询
result = router.route("Will it rain tomorrow?", top_k=1)
print("Best route:", result[0] if result else None)
```

## 运行测试

```bash
# 运行单元测试
python -m pytest tests/test_basic.py -v

# 运行性能测试
python examples/performance_test.py
```

## 核心组件

### Vectorizer（向量化器）

- `BaseVectorizer`: 抽象基类，定义向量化接口
- `SentenceTransformerVectorizer`: 基于 sentence-transformers 的实现

### Storage（存储）

- `BaseVectorStorage`: 向量存储抽象接口
- `FaissStorage`: 基于 Faiss 的向量存储，支持保存和加载索引
- `RedisStorage`: Redis 连接管理，支持连接池

### Cache（缓存）

- `SemanticCache`: 语义缓存，支持 TTL 和距离阈值
- `EmbeddingCache`: 嵌入结果缓存
- `CachedVectorizer`: 带缓存的向量器包装器

### Message History（消息历史）

- `SemanticMessageHistory`: 语义消息历史管理
- 支持按时间和语义相似度检索

### Router（路由）

- `SemanticRouter`: 语义路由
- `Route`: 路由规则定义

## 扩展开发

### 自定义向量器

继承 `BaseVectorizer` 并实现以下方法：

```python
from ai_vector_cache import BaseVectorizer
import numpy as np

class MyVectorizer(BaseVectorizer):
    def embed(self, text: str) -> np.ndarray:
        # 实现你的向量化逻辑
        pass
    
    def embed_many(self, texts: list[str]) -> list[np.ndarray]:
        # 实现批量向量化
        pass
    
    @property
    def dimension(self) -> int:
        # 返回向量维度
        return 384
```

## 性能优化建议

1. 使用 Faiss 的 IVF 索引类型加速大规模数据检索
2. 合理设置缓存 TTL，避免内存占用过高
3. 使用 Redis 连接池提高并发性能
4. 对于大量数据，考虑分批加载

## 许可证

MIT License
