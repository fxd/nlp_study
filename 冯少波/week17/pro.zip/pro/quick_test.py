#!/usr/bin/env python3
"""快速测试核心功能，不依赖外部服务"""

import sys
import numpy as np

print("=" * 60)
print("AI Vector Cache - 快速测试")
print("=" * 60)

# 测试 1: 测试模块导入
print("\n[1/4] 测试模块导入...")
try:
    from ai_vector_cache import setup_logger
    print("  ✓ 模块导入成功")
except Exception as e:
    print(f"  ✗ 模块导入失败: {e}")
    sys.exit(1)

# 测试 2: 测试 Mock 向量器
print("\n[2/4] 测试向量器接口...")
try:
    from ai_vector_cache import BaseVectorizer
    
    class SimpleVectorizer(BaseVectorizer):
        def __init__(self, dimension: int = 10):
            self._dimension = dimension
        
        def embed(self, text: str) -> np.ndarray:
            # 简单的哈希向量化，仅供测试
            np.random.seed(hash(text) % (2**32))
            return np.random.randn(self._dimension).astype(np.float32)
        
        def embed_many(self, texts: list[str]) -> list[np.ndarray]:
            return [self.embed(text) for text in texts]
        
        @property
        def dimension(self) -> int:
            return self._dimension
    
    vectorizer = SimpleVectorizer(dimension=10)
    embedding = vectorizer.embed("Hello world")
    
    print(f"  ✓ 向量化成功，维度: {embedding.shape}")
    assert embedding.shape == (10,)
except Exception as e:
    print(f"  ✗ 向量器测试失败: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# 测试 3: 测试 Faiss 存储
print("\n[3/4] 测试 Faiss 存储...")
try:
    from ai_vector_cache import FaissStorage
    
    storage = FaissStorage(dimension=10)
    
    # 添加测试数据
    storage.add("key1", vectorizer.embed("text1"))
    storage.add("key2", vectorizer.embed("text2"))
    
    # 测试搜索
    results = storage.search(vectorizer.embed("text1"), top_k=2)
    print(f"  ✓ 搜索成功，返回 {len(results)} 个结果")
    
    # 测试保存和加载
    import tempfile
    with tempfile.NamedTemporaryFile(delete=False, suffix="") as f:
        temp_path = f.name
    
    storage.save(temp_path)
    print(f"  ✓ 索引已保存到: {temp_path}")
    
    loaded_storage = FaissStorage.load(temp_path)
    loaded_results = loaded_storage.search(vectorizer.embed("text1"), top_k=2)
    print(f"  ✓ 索引加载成功，搜索返回 {len(loaded_results)} 个结果")
    
    # 清理临时文件
    import os
    for ext in [".index", ".meta"]:
        try:
            os.unlink(temp_path + ext)
        except OSError:
            pass
            
except ImportError:
    print("  ⚠ Faiss 未安装，跳过此测试")
except Exception as e:
    print(f"  ✗ Faiss 存储测试失败: {e}")
    import traceback
    traceback.print_exc()

# 测试 4: 测试语义缓存
print("\n[4/4] 测试语义缓存...")
try:
    from ai_vector_cache import FaissStorage, SemanticCache
    
    storage = FaissStorage(dimension=10)
    cache = SemanticCache(
        vectorizer=vectorizer,
        vector_storage=storage,
        similarity_threshold=0.0
    )
    
    # 存储缓存
    cache.set("What is the capital?", "Paris")
    print("  ✓ 缓存存储成功")
    
    # 测试查询
    result = cache.get("What is the capital?")
    if result:
        print(f"  ✓ 缓存命中: {result}")
    else:
        print("  ⚠ 缓存未命中（可能是Mock向量化的相似度问题）")
        
except ImportError:
    print("  ⚠ 缺少依赖，跳过此测试")
except Exception as e:
    print(f"  ✗ 语义缓存测试失败: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "=" * 60)
print("快速测试完成！")
print("=" * 60)
print("\n提示:")
print("- 要使用完整功能，请安装 requirements.txt 中的所有依赖")
print("- 要使用真实向量化，请安装 sentence-transformers")
print("- 要使用 Redis 功能，请确保 Redis 服务正常运行")
