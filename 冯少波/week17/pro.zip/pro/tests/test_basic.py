#!/usr/bin/env python3
"""Basic unit tests for AI Vector Cache"""
import os
import tempfile
import numpy as np
import pytest

from ai_vector_cache import (
    setup_logger,
    BaseVectorizer,
    SentenceTransformerVectorizer,
    FaissStorage,
    RedisStorage,
    SemanticCache,
    EmbeddingCache,
    CachedVectorizer,
    SemanticMessageHistory,
    SemanticRouter,
    Route
)


class MockVectorizer(BaseVectorizer):
    """Mock vectorizer for testing"""
    def __init__(self, dimension: int = 10):
        self._dimension = dimension
    
    def embed(self, text: str) -> np.ndarray:
        # Generate deterministic vector based on text
        seed = sum(ord(c) for c in text) % 10000
        np.random.seed(seed)
        return np.random.randn(self._dimension).astype(np.float32)
    
    def embed_many(self, texts: list[str]) -> list[np.ndarray]:
        return [self.embed(text) for text in texts]
    
    @property
    def dimension(self) -> int:
        return self._dimension


class TestVectorizer:
    """Tests for vectorizers"""
    
    def test_mock_vectorizer(self):
        """Test mock vectorizer works"""
        vectorizer = MockVectorizer(dimension=10)
        vector = vectorizer.embed("test")
        
        assert vector.shape == (10,)
        assert isinstance(vector, np.ndarray)
    
    def test_embedding_consistency(self):
        """Test same text gives same embedding"""
        vectorizer = MockVectorizer(dimension=10)
        v1 = vectorizer.embed("hello")
        v2 = vectorizer.embed("hello")
        
        assert np.array_equal(v1, v2)


class TestFaissStorage:
    """Tests for Faiss storage"""
    
    def test_add_and_search(self):
        """Test adding vectors and searching"""
        storage = FaissStorage(dimension=10)
        
        # Add some vectors
        storage.add("key1", np.random.randn(10).astype(np.float32))
        storage.add("key2", np.random.randn(10).astype(np.float32))
        
        # Search for nearest
        results = storage.search(np.random.randn(10).astype(np.float32), top_k=2)
        
        assert len(results) == 2
    
    def test_get_vector(self):
        """Test retrieving a vector by key"""
        storage = FaissStorage(dimension=10)
        vector = np.random.randn(10).astype(np.float32)
        
        storage.add("test_key", vector)
        retrieved = storage.get("test_key")
        
        assert retrieved is not None
        assert np.array_equal(vector, retrieved)
    
    def test_clear(self):
        """Test clearing storage"""
        storage = FaissStorage(dimension=10)
        storage.add("key1", np.random.randn(10))
        
        storage.clear()
        
        assert storage.get("key1") is None
    
    def test_save_and_load(self):
        """Test saving and loading Faiss index"""
        storage = FaissStorage(dimension=10)
        vector = np.random.randn(10).astype(np.float32)
        storage.add("test_key", vector)
        
        # Save to temp file
        with tempfile.NamedTemporaryFile(delete=False) as f:
            temp_path = f.name
        
        try:
            storage.save(temp_path)
            
            # Load from file
            loaded_storage = FaissStorage.load(temp_path)
            retrieved = loaded_storage.get("test_key")
            
            assert retrieved is not None
            assert np.array_equal(vector, retrieved)
        finally:
            # Clean up
            for ext in ['.index', '.meta']:
                try:
                    os.unlink(temp_path + ext)
                except OSError:
                    pass


class TestSemanticCache:
    """Tests for semantic cache"""
    
    def test_set_and_get(self):
        """Test setting and getting cache entries"""
        vectorizer = MockVectorizer(dimension=10)
        storage = FaissStorage(dimension=10)
        cache = SemanticCache(vectorizer, storage, similarity_threshold=0.0)
        
        cache.set("question1", "answer1")
        cache.set("question2", "answer2")
        
        # Get exact match (will be semantic match with our mock)
        result = cache.get("question1")
        assert result == "answer1"
    
    def test_clear(self):
        """Test clearing cache"""
        vectorizer = MockVectorizer(dimension=10)
        storage = FaissStorage(dimension=10)
        cache = SemanticCache(vectorizer, storage)
        
        cache.set("question", "answer")
        cache.clear()
        
        # Should not find anything after clear
        result = cache.get("question")
        assert result is None


class TestEmbeddingCache:
    """Tests for embedding cache"""
    
    def test_set_and_get(self):
        """Test setting and getting embeddings"""
        cache = EmbeddingCache()
        vector = np.random.randn(10).astype(np.float32)
        
        cache.set("test text", "test_model", vector)
        retrieved = cache.get("test text", "test_model")
        
        assert retrieved is not None
        assert np.array_equal(vector, retrieved)


class TestCachedVectorizer:
    """Tests for cached vectorizer"""
    
    def test_cache_hits(self):
        """Test that cache works correctly"""
        base_vectorizer = MockVectorizer(dimension=10)
        cached = CachedVectorizer(base_vectorizer)
        
        # First call
        v1 = cached.embed("test")
        
        # Second call should be from cache
        v2 = cached.embed("test")
        
        assert np.array_equal(v1, v2)


class TestSemanticMessageHistory:
    """Tests for message history"""
    
    def test_add_and_get_recent(self):
        """Test adding messages and retrieving recent"""
        vectorizer = MockVectorizer(dimension=10)
        storage = FaissStorage(dimension=10)
        history = SemanticMessageHistory(vectorizer, storage)
        
        history.add_message("user", "hello")
        history.add_message("assistant", "hi there")
        history.add_message("user", "how are you?")
        
        recent = history.get_recent(2)
        
        assert len(recent) == 2
        assert recent[0]["content"] == "hi there"
        assert recent[1]["content"] == "how are you?"


class TestSemanticRouter:
    """Tests for semantic router"""
    
    def test_route(self):
        """Test routing functionality"""
        vectorizer = MockVectorizer(dimension=10)
        storage = FaissStorage(dimension=10)
        router = SemanticRouter(vectorizer, storage)
        
        route1 = Route("greeting", ["hello", "hi", "hey"])
        route2 = Route("weather", ["rain", "sun", "temperature"])
        
        router.add_route(route1)
        router.add_route(route2)
        
        # Route a greeting
        results = router.route("hello there")
        
        assert len(results) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
