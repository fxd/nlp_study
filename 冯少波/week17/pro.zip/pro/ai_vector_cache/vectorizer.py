import logging
from abc import ABC, abstractmethod
from typing import List, Optional

import numpy as np

logger = logging.getLogger(__name__)


class BaseVectorizer(ABC):
    @abstractmethod
    def embed(self, text: str) -> np.ndarray:
        pass
    
    @abstractmethod
    def embed_many(self, texts: List[str]) -> List[np.ndarray]:
        pass
    
    @property
    @abstractmethod
    def dimension(self) -> int:
        pass


class SentenceTransformerVectorizer(BaseVectorizer):
    def __init__(
        self,
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        dimension: Optional[int] = None
    ):
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError:
            raise ImportError(
                "sentence-transformers is not installed. "
                "Please install it with: pip install sentence-transformers"
            )
        
        self._model_name = model_name
        self._model = SentenceTransformer(model_name)
        self._dimension = dimension or self._model.get_sentence_embedding_dimension()
        logger.info(f"Loaded vectorizer: {model_name}, dimension: {self._dimension}")
    
    def embed(self, text: str) -> np.ndarray:
        embedding = self._model.encode(text, convert_to_numpy=True)
        if embedding.shape[0] > self._dimension:
            embedding = embedding[:self._dimension]
        return embedding
    
    def embed_many(self, texts: List[str]) -> List[np.ndarray]:
        embeddings = self._model.encode(texts, convert_to_numpy=True)
        if embeddings.shape[1] > self._dimension:
            embeddings = embeddings[:, :self._dimension]
        return [emb for emb in embeddings]
    
    @property
    def dimension(self) -> int:
        return self._dimension
