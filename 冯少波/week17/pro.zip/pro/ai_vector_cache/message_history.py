import logging
from typing import List, Dict, Any, Optional

import numpy as np

from .vectorizer import BaseVectorizer
from .storage import BaseVectorStorage

logger = logging.getLogger(__name__)


class Message:
    def __init__(self, role: str, content: str, metadata: Optional[Dict[str, Any]] = None):
        self.role = role
        self.content = content
        self.metadata = metadata or {}
        self.timestamp = None


class SemanticMessageHistory:
    def __init__(
        self,
        vectorizer: BaseVectorizer,
        vector_storage: BaseVectorStorage,
        max_messages: Optional[int] = None
    ):
        self._vectorizer = vectorizer
        self._vector_storage = vector_storage
        self._max_messages = max_messages
        self._messages: List[Message] = []
        logger.info("Initialized SemanticMessageHistory")
    
    def add_message(self, role: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        message = Message(role, content, metadata)
        self._messages.append(message)
        
        key = f"msg_{len(self._messages) - 1}"
        vector = self._vectorizer.embed(content)
        self._vector_storage.add(key, vector)
        
        if self._max_messages and len(self._messages) > self._max_messages:
            self._messages.pop(0)
    
    def search_similar(
        self,
        query: str,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        query_vector = self._vectorizer.embed(query)
        results = self._vector_storage.search(query_vector, top_k)
        
        similar_messages = []
        for key, distance in results:
            try:
                idx = int(key.split("_")[1])
                if 0 <= idx < len(self._messages):
                    msg = self._messages[idx]
                    similar_messages.append({
                        "role": msg.role,
                        "content": msg.content,
                        "metadata": msg.metadata,
                        "distance": distance
                    })
            except (IndexError, ValueError):
                continue
        
        return similar_messages
    
    def get_recent(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        messages = self._messages[-limit:] if limit else self._messages
        return [
            {"role": m.role, "content": m.content, "metadata": m.metadata}
            for m in messages
        ]
    
    def clear(self) -> None:
        self._messages.clear()
        self._vector_storage.clear()
        logger.info("Message history cleared")
