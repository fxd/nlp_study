import logging
import pickle
import os
from abc import ABC, abstractmethod
from typing import List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


class BaseVectorStorage(ABC):
    @abstractmethod
    def add(self, key: str, vector: np.ndarray) -> None:
        pass
    
    @abstractmethod
    def add_batch(self, keys: List[str], vectors: List[np.ndarray]) -> None:
        pass
    
    @abstractmethod
    def search(self, query_vector: np.ndarray, top_k: int = 5) -> List[Tuple[str, float]]:
        pass
    
    @abstractmethod
    def get(self, key: str) -> Optional[np.ndarray]:
        pass
    
    @abstractmethod
    def delete(self, key: str) -> bool:
        pass
    
    @abstractmethod
    def clear(self) -> None:
        pass


class FaissStorage(BaseVectorStorage):
    def __init__(self, dimension: int, index_type: str = "flat"):
        try:
            import faiss
        except ImportError:
            raise ImportError(
                "faiss-cpu is not installed. "
                "Please install it with: pip install faiss-cpu"
            )
        
        self._dimension = dimension
        self._index_type = index_type
        self._index = self._create_index(index_type, dimension)
        self._key_to_idx: dict = {}
        self._idx_to_key: dict = {}
        self._next_idx = 0
        self._vectors: dict = {}  # Store vectors for get() operation
        logger.info(f"Initialized Faiss storage with dimension: {dimension}, type: {index_type}")
    
    def _create_index(self, index_type: str, dimension: int):
        import faiss
        if index_type == "flat":
            return faiss.IndexFlatL2(dimension)
        elif index_type == "ivf":
            nlist = min(100, 4096)  # Number of clusters
            quantizer = faiss.IndexFlatL2(dimension)
            index = faiss.IndexIVFFlat(quantizer, dimension, nlist)
            index.nprobe = 10  # Number of clusters to search
            return index
        else:
            return faiss.IndexFlatL2(dimension)
    
    def add(self, key: str, vector: np.ndarray) -> None:
        if key in self._key_to_idx:
            logger.warning(f"Key {key} already exists, skipping")
            return
        
        vector = vector.astype(np.float32).reshape(1, -1)
        self._vectors[key] = vector.copy()
        self._index.add(vector)
        self._key_to_idx[key] = self._next_idx
        self._idx_to_key[self._next_idx] = key
        self._next_idx += 1
    
    def add_batch(self, keys: List[str], vectors: List[np.ndarray]) -> None:
        new_keys = []
        new_vectors = []
        
        for key, vector in zip(keys, vectors):
            if key not in self._key_to_idx:
                new_keys.append(key)
                new_vectors.append(vector)
        
        if not new_keys:
            return
        
        vectors_np = np.vstack(new_vectors).astype(np.float32)
        start_idx = self._next_idx
        self._index.add(vectors_np)
        
        for i, key in enumerate(new_keys):
            idx = start_idx + i
            self._key_to_idx[key] = idx
            self._idx_to_key[idx] = key
            self._vectors[key] = vectors_np[i:i+1].copy()
        
        self._next_idx += len(new_keys)
        logger.info(f"Added {len(new_keys)} vectors to Faiss storage")
    
    def search(self, query_vector: np.ndarray, top_k: int = 5) -> List[Tuple[str, float]]:
        if self._index.ntotal == 0:
            return []
        
        query_vector = query_vector.astype(np.float32).reshape(1, -1)
        distances, indices = self._index.search(query_vector, min(top_k, self._index.ntotal))
        
        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx in self._idx_to_key:
                results.append((self._idx_to_key[idx], float(dist)))
        
        return results
    
    def get(self, key: str) -> Optional[np.ndarray]:
        if key in self._vectors:
            return self._vectors[key].flatten()
        return None
    
    def delete(self, key: str) -> bool:
        if key not in self._key_to_idx:
            return False
        
        logger.warning("FaissStorage.delete() is not efficient, will rebuild index on next save")
        del self._vectors[key]
        del self._key_to_idx[key]
        # Note: For simplicity, we don't actually delete from Faiss index here
        # A more efficient implementation would use IDMap
        return True
    
    def clear(self) -> None:
        import faiss
        self._index = self._create_index(self._index_type, self._dimension)
        self._key_to_idx.clear()
        self._idx_to_key.clear()
        self._vectors.clear()
        self._next_idx = 0
        logger.info("Faiss storage cleared")
    
    def save(self, path: str) -> None:
        """Save Faiss index and metadata to disk"""
        import faiss
        
        data = {
            "dimension": self._dimension,
            "index_type": self._index_type,
            "key_to_idx": self._key_to_idx,
            "idx_to_key": self._idx_to_key,
            "next_idx": self._next_idx,
            "vectors": self._vectors
        }
        
        index_path = f"{path}.index"
        meta_path = f"{path}.meta"
        
        faiss.write_index(self._index, index_path)
        with open(meta_path, "wb") as f:
            pickle.dump(data, f)
        
        logger.info(f"Faiss storage saved to {path}")
    
    @classmethod
    def load(cls, path: str) -> "FaissStorage":
        """Load Faiss index and metadata from disk"""
        import faiss
        
        index_path = f"{path}.index"
        meta_path = f"{path}.meta"
        
        if not os.path.exists(index_path) or not os.path.exists(meta_path):
            raise FileNotFoundError(f"Index files not found at {path}")
        
        with open(meta_path, "rb") as f:
            data = pickle.load(f)
        
        storage = cls(data["dimension"], data["index_type"])
        storage._index = faiss.read_index(index_path)
        storage._key_to_idx = data["key_to_idx"]
        storage._idx_to_key = data["idx_to_key"]
        storage._next_idx = data["next_idx"]
        storage._vectors = data["vectors"]
        
        logger.info(f"Faiss storage loaded from {path}")
        return storage


class RedisStorage:
    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: Optional[str] = None,
        max_connections: int = 10
    ):
        try:
            import redis
        except ImportError:
            raise ImportError(
                "redis is not installed. "
                "Please install it with: pip install redis"
            )
        
        self._pool = redis.ConnectionPool(
            host=host,
            port=port,
            db=db,
            password=password,
            max_connections=max_connections,
            decode_responses=False
        )
        self._client = redis.Redis(connection_pool=self._pool)
        self._client.ping()
        logger.info(f"Connected to Redis at {host}:{port} with connection pool")
    
    def set(self, key: str, value: bytes, expire: Optional[int] = None) -> None:
        self._client.set(key, value, ex=expire)
    
    def get(self, key: str) -> Optional[bytes]:
        return self._client.get(key)
    
    def delete(self, key: str) -> bool:
        return bool(self._client.delete(key))
    
    def exists(self, key: str) -> bool:
        return bool(self._client.exists(key))
    
    def clear(self, pattern: str = "*") -> None:
        keys = self._client.keys(pattern)
        if keys:
            self._client.delete(*keys)
        logger.info(f"Cleared {len(keys)} keys from Redis")
    
    def close(self) -> None:
        self._pool.disconnect()
