import logging
import json
import hashlib
from typing import Any, Optional, Callable
from dataclasses import dataclass
from time import time

import numpy as np

from .vectorizer import BaseVectorizer
from .storage import BaseVectorStorage, RedisStorage

logger = logging.getLogger(__name__)


@dataclass
class CacheEntry:
    value: Any
    created_at: float
    ttl: Optional[int] = None
    
    def is_expired(self) -> bool:
        if self.ttl is None:
            return False
        return time() - self.created_at > self.ttl


class SemanticCache:
    def __init__(
        self,
        vectorizer: BaseVectorizer,
        vector_storage: BaseVectorStorage,
        redis_storage: Optional[RedisStorage] = None,
        similarity_threshold: float = 0.5,
        default_ttl: Optional[int] = None
    ):
        self._vectorizer = vectorizer
        self._vector_storage = vector_storage
        self._redis_storage = redis_storage
        self._similarity_threshold = similarity_threshold
        self._default_ttl = default_ttl
        self._local_cache: dict = {}
        logger.info("Initialized SemanticCache")
    
    def _get_key(self, text: str) -> str:
        return hashlib.md5(text.encode()).hexdigest()
    
    def get(self, query: str) -> Optional[Any]:
        query_vector = self._vectorizer.embed(query)
        results = self._vector_storage.search(query_vector, top_k=1)
        
        if not results:
            return None
        
        key, distance = results[0]
        similarity = 1.0 / (1.0 + distance)
        
        if similarity >= self._similarity_threshold:
            if key in self._local_cache:
                entry = self._local_cache[key]
                if not entry.is_expired():
                    logger.info(f"Cache hit (local) for query: {query[:50]}...")
                    return entry.value
                else:
                    del self._local_cache[key]
            
            if self._redis_storage:
                value_bytes = self._redis_storage.get(key)
                if value_bytes:
                    logger.info(f"Cache hit (Redis) for query: {query[:50]}...")
                    return json.loads(value_bytes)
        
        return None
    
    def set(self, query: str, value: Any, ttl: Optional[int] = None) -> None:
        key = self._get_key(query)
        query_vector = self._vectorizer.embed(query)
        
        self._vector_storage.add(key, query_vector)
        
        ttl = ttl or self._default_ttl
        self._local_cache[key] = CacheEntry(value=value, created_at=time(), ttl=ttl)
        
        if self._redis_storage:
            self._redis_storage.set(key, json.dumps(value).encode(), expire=ttl)
        
        logger.info(f"Cache set for query: {query[:50]}...")
    
    def clear(self) -> None:
        self._local_cache.clear()
        self._vector_storage.clear()
        if self._redis_storage:
            self._redis_storage.clear()
        logger.info("Semantic cache cleared")


class EmbeddingCache:
    def __init__(self, redis_storage: Optional[RedisStorage] = None, default_ttl: Optional[int] = 3600):
        self._redis_storage = redis_storage
        self._default_ttl = default_ttl
        self._local_cache: dict = {}
        logger.info("Initialized EmbeddingCache")
    
    def _get_key(self, text: str, model_name: str) -> str:
        combined = f"{model_name}:{text}"
        return hashlib.md5(combined.encode()).hexdigest()
    
    def get(self, text: str, model_name: str) -> Optional[np.ndarray]:
        key = self._get_key(text, model_name)
        
        if key in self._local_cache:
            entry = self._local_cache[key]
            if not entry.is_expired():
                return entry.value
            else:
                del self._local_cache[key]
        
        if self._redis_storage:
            value_bytes = self._redis_storage.get(key)
            if value_bytes:
                return np.frombuffer(value_bytes, dtype=np.float32)
        
        return None
    
    def set(self, text: str, model_name: str, embedding: np.ndarray, ttl: Optional[int] = None) -> None:
        key = self._get_key(text, model_name)
        ttl = ttl or self._default_ttl
        self._local_cache[key] = CacheEntry(value=embedding, created_at=time(), ttl=ttl)
        
        if self._redis_storage:
            self._redis_storage.set(key, embedding.tobytes(), expire=ttl)
    
    def clear(self) -> None:
        self._local_cache.clear()
        if self._redis_storage:
            self._redis_storage.clear()
        logger.info("Embedding cache cleared")


class CachedVectorizer(BaseVectorizer):
    """Wrapper for BaseVectorizer that caches embeddings"""
    def __init__(
        self,
        vectorizer: BaseVectorizer,
        embedding_cache: Optional[EmbeddingCache] = None,
        redis_storage: Optional[RedisStorage] = None,
        default_ttl: Optional[int] = 3600
    ):
        self._vectorizer = vectorizer
        self._model_name = getattr(vectorizer, '_model_name', 'default')
        
        if embedding_cache:
            self._cache = embedding_cache
        else:
            self._cache = EmbeddingCache(redis_storage=redis_storage, default_ttl=default_ttl)
        
        logger.info("Initialized CachedVectorizer")
    
    def embed(self, text: str) -> np.ndarray:
        cached = self._cache.get(text, self._model_name)
        if cached is not None:
            logger.debug(f"Embedding cache hit for: {text[:30]}...")
            return cached
        
        embedding = self._vectorizer.embed(text)
        self._cache.set(text, self._model_name, embedding)
        return embedding
    
    def embed_many(self, texts: list[str]) -> list[np.ndarray]:
        # Check which texts are cached
        uncached_texts = []
        cached_embeddings = {}
        
        for text in texts:
            cached = self._cache.get(text, self._model_name)
            if cached is not None:
                cached_embeddings[text] = cached
            else:
                uncached_texts.append(text)
        
        # Embed uncached texts
        if uncached_texts:
            new_embeddings = self._vectorizer.embed_many(uncached_texts)
            for text, embedding in zip(uncached_texts, new_embeddings):
                cached_embeddings[text] = embedding
                self._cache.set(text, self._model_name, embedding)
        
        # Return in original order
        return [cached_embeddings[text] for text in texts]
    
    @property
    def dimension(self) -> int:
        return self._vectorizer.dimension
