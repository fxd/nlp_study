import logging
from typing import List, Dict, Any, Callable, Optional

import numpy as np

from .vectorizer import BaseVectorizer
from .storage import BaseVectorStorage

logger = logging.getLogger(__name__)


class Route:
    def __init__(
        self,
        name: str,
        examples: List[str],
        handler: Optional[Callable] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.name = name
        self.examples = examples
        self.handler = handler
        self.metadata = metadata or {}


class SemanticRouter:
    def __init__(
        self,
        vectorizer: BaseVectorizer,
        vector_storage: BaseVectorStorage
    ):
        self._vectorizer = vectorizer
        self._vector_storage = vector_storage
        self._routes: Dict[str, Route] = {}
        logger.info("Initialized SemanticRouter")
    
    def add_route(self, route: Route) -> None:
        self._routes[route.name] = route
        
        for i, example in enumerate(route.examples):
            key = f"route_{route.name}_{i}"
            vector = self._vectorizer.embed(example)
            self._vector_storage.add(key, vector)
        
        logger.info(f"Added route: {route.name} with {len(route.examples)} examples")
    
    def route(
        self,
        query: str,
        top_k: int = 3
    ) -> List[Dict[str, Any]]:
        query_vector = self._vectorizer.embed(query)
        results = self._vector_storage.search(query_vector, top_k)
        
        route_scores: Dict[str, List[float]] = {}
        
        for key, distance in results:
            try:
                parts = key.split("_")
                if len(parts) >= 3 and parts[0] == "route":
                    route_name = parts[1]
                    if route_name not in route_scores:
                        route_scores[route_name] = []
                    route_scores[route_name].append(1.0 / (1.0 + distance))
            except (IndexError, ValueError):
                continue
        
        sorted_routes = []
        for route_name, scores in route_scores.items():
            avg_score = sum(scores) / len(scores)
            sorted_routes.append({
                "route": route_name,
                "score": avg_score,
                "handler": self._routes[route_name].handler,
                "metadata": self._routes[route_name].metadata
            })
        
        sorted_routes.sort(key=lambda x: x["score"], reverse=True)
        return sorted_routes
    
    def get_best_route(self, query: str) -> Optional[Dict[str, Any]]:
        routes = self.route(query, top_k=3)
        return routes[0] if routes else None
