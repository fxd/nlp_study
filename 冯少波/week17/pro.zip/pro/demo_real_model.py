#!/usr/bin/env python3
"""使用真实模型的快速演示"""

from ai_vector_cache import setup_logger, SentenceTransformerVectorizer, FaissStorage, SemanticCache

print("=" * 60)
print("使用真实 Sentence-Transformers 模型")
print("=" * 60)

logger = setup_logger(level="INFO")
logger.info("初始化向量器（这会下载模型）...")

# 初始化向量器（使用较小的模型）
vectorizer = SentenceTransformerVectorizer(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

print(f"\n✓ 向量器初始化完成")
print(f"  - 模型: {vectorizer._model_name}")
print(f"  - 向量维度: {vectorizer.dimension}")

# 测试向量化
print("\n[1] 测试向量化...")
embedding = vectorizer.embed("Hello, how are you?")
print(f"✓ 单个文本向量化成功，形状: {embedding.shape}")

embeddings = vectorizer.embed_many(["Hello!", "How are you?", "What's up?"])
print(f"✓ 批量向量化成功，处理了 {len(embeddings)} 个文本")

# 测试向量存储
print("\n[2] 测试 Faiss 存储...")
storage = FaissStorage(dimension=vectorizer.dimension)

# 添加一些向量
texts = [
    "The capital of France is Paris",
    "Python is a programming language",
    "The weather is nice today",
    "Machine learning is a subset of AI"
]

for i, text in enumerate(texts):
    vec = vectorizer.embed(text)
    storage.add(f"doc_{i}", vec)
print(f"✓ 添加了 {len(texts)} 个文档到 Faiss 存储")

# 测试搜索
query = "What is the capital of Italy?"
query_vec = vectorizer.embed(query)
results = storage.search(query_vec, top_k=2)
print(f"\n查询: '{query}'")
print("搜索结果:")
for key, distance in results:
    idx = int(key.split("_")[1])
    print(f"  - {texts[idx]} (距离: {distance:.4f})")

# 测试语义缓存
print("\n[3] 测试语义缓存...")
cache = SemanticCache(
    vectorizer=vectorizer,
    vector_storage=storage,
    similarity_threshold=0.6
)

# 添加缓存
cache.set("What is Python?", "Python is a programming language created by Guido van Rossum.")
cache.set("Who created Python?", "Python was created by Guido van Rossum.")
cache.set("What is the capital of France?", "Paris is the capital of France.")

# 测试缓存命中
print("\n查询1: 'Tell me about Python'")
result1 = cache.get("Tell me about Python")
print(f"  缓存结果: {result1}")

print("\n查询2: 'What programming language was made by Guido?'")
result2 = cache.get("What programming language was made by Guido?")
print(f"  缓存结果: {result2}")

print("\n查询3: 'What's France's capital city?'")
result3 = cache.get("What's France's capital city?")
print(f"  缓存结果: {result3}")

print("\n" + "=" * 60)
print("✓ 所有功能测试完成！")
print("=" * 60)
