#!/usr/bin/env python3
"""Basic usage example of AI Vector Cache"""

from ai_vector_cache import setup_logger, SentenceTransformerVectorizer
from ai_vector_cache.storage import FaissStorage
from ai_vector_cache.cache import SemanticCache
from ai_vector_cache.message_history import SemanticMessageHistory
from ai_vector_cache.router import SemanticRouter, Route


def main():
    logger = setup_logger(level="INFO")
    logger.info("Starting AI Vector Cache example")
    
    vectorizer = SentenceTransformerVectorizer()
    faiss_storage = FaissStorage(dimension=vectorizer.dimension)
    
    semantic_cache = SemanticCache(
        vectorizer=vectorizer,
        vector_storage=faiss_storage,
        similarity_threshold=0.7
    )
    
    semantic_cache.set("What is the capital of France?", "Paris")
    semantic_cache.set("Tell me about Python", "Python is a programming language")
    
    result = semantic_cache.get("What's the capital city of France?")
    logger.info(f"Cache result: {result}")
    
    msg_history = SemanticMessageHistory(
        vectorizer=vectorizer,
        vector_storage=FaissStorage(dimension=vectorizer.dimension)
    )
    
    msg_history.add_message("user", "Hello, how are you?")
    msg_history.add_message("assistant", "I'm fine, thank you!")
    msg_history.add_message("user", "What's the weather today?")
    
    similar = msg_history.search_similar("Hi there", top_k=2)
    logger.info(f"Similar messages: {similar}")
    
    router = SemanticRouter(
        vectorizer=vectorizer,
        vector_storage=FaissStorage(dimension=vectorizer.dimension)
    )
    
    router.add_route(Route(
        name="weather",
        examples=["What's the weather?", "Is it raining?", "Temperature today"]
    ))
    router.add_route(Route(
        name="coding",
        examples=["How to code Python?", "Debug my program", "Software development"]
    ))
    
    best_route = router.get_best_route("Will it rain tomorrow?")
    logger.info(f"Best route: {best_route}")


if __name__ == "__main__":
    main()
