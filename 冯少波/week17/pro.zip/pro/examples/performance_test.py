#!/usr/bin/env python3
"""Performance test for AI Vector Cache"""
import time
import random
import numpy as np

from ai_vector_cache import (
    setup_logger,
    SentenceTransformerVectorizer,
    FaissStorage,
    CachedVectorizer,
    SemanticCache
)


def generate_random_texts(num: int = 100) -> list:
    """Generate random test texts"""
    subjects = ["apple", "banana", "car", "dog", "elephant", "flower", "guitar", "house"]
    actions = ["is red", "is fast", "is big", "is beautiful", "sings well", "runs fast"]
    
    texts = []
    for _ in range(num):
        subject = random.choice(subjects)
        action = random.choice(actions)
        texts.append(f"The {subject} {action}")
    
    return texts


def test_embedding_performance():
    """Test embedding cache performance"""
    logger = setup_logger(level="INFO")
    
    logger.info("=" * 60)
    logger.info("Testing Embedding Cache Performance")
    logger.info("=" * 60)
    
    # Initialize vectorizer
    vectorizer = SentenceTransformerVectorizer()
    
    # Generate test data
    test_texts = generate_random_texts(50)
    
    # Test without cache
    logger.info("\n--- Testing without cache ---")
    start_time = time.time()
    for text in test_texts:
        vectorizer.embed(text)
    no_cache_time = time.time() - start_time
    logger.info(f"Time without cache: {no_cache_time:.4f}s")
    
    # Test with cache
    logger.info("\n--- Testing with cache ---")
    cached_vectorizer = CachedVectorizer(vectorizer)
    
    # First pass (populate cache)
    start_time = time.time()
    for text in test_texts:
        cached_vectorizer.embed(text)
    first_pass_time = time.time() - start_time
    logger.info(f"First pass (populate cache): {first_pass_time:.4f}s")
    
    # Second pass (use cache)
    start_time = time.time()
    for text in test_texts:
        cached_vectorizer.embed(text)
    cache_hit_time = time.time() - start_time
    logger.info(f"Second pass (cache hits): {cache_hit_time:.4f}s")
    
    # Calculate speedup
    speedup = no_cache_time / cache_hit_time if cache_hit_time > 0 else float('inf')
    logger.info(f"\nSpeedup: {speedup:.2f}x faster with cache!")
    
    return no_cache_time, first_pass_time, cache_hit_time


def test_semantic_cache():
    """Test semantic cache"""
    logger = setup_logger(level="INFO")
    
    logger.info("\n" + "=" * 60)
    logger.info("Testing Semantic Cache")
    logger.info("=" * 60)
    
    vectorizer = SentenceTransformerVectorizer()
    storage = FaissStorage(dimension=vectorizer.dimension)
    cache = SemanticCache(
        vectorizer=vectorizer,
        vector_storage=storage,
        similarity_threshold=0.7
    )
    
    # Add some entries
    cache.set("What is the capital of France?", "Paris")
    cache.set("How do I make pasta?", "Boil water and add pasta.")
    cache.set("What is Python?", "Python is a programming language.")
    
    # Test exact match
    logger.info("\n--- Testing exact match ---")
    start_time = time.time()
    result = cache.get("What is the capital of France?")
    exact_time = time.time() - start_time
    logger.info(f"Exact match result: {result}, time: {exact_time:.6f}s")
    
    # Test semantic match
    logger.info("\n--- Testing semantic match ---")
    start_time = time.time()
    result = cache.get("Which city is the capital of France?")
    semantic_time = time.time() - start_time
    logger.info(f"Semantic match result: {result}, time: {semantic_time:.6f}s")
    
    # Test no match
    logger.info("\n--- Testing no match ---")
    start_time = time.time()
    result = cache.get("What is the meaning of life?")
    no_match_time = time.time() - start_time
    logger.info(f"No match result: {result}, time: {no_match_time:.6f}s")


def test_vector_search_performance():
    """Test vector search performance"""
    logger = setup_logger(level="INFO")
    
    logger.info("\n" + "=" * 60)
    logger.info("Testing Vector Search Performance")
    logger.info("=" * 60)
    
    vectorizer = SentenceTransformerVectorizer()
    storage = FaissStorage(dimension=vectorizer.dimension)
    
    # Add test data
    num_vectors = 1000
    logger.info(f"\nAdding {num_vectors} vectors...")
    texts = generate_random_texts(num_vectors)
    vectors = vectorizer.embed_many(texts)
    
    start_time = time.time()
    for i, (text, vector) in enumerate(zip(texts, vectors)):
        storage.add(f"text_{i}", vector)
    add_time = time.time() - start_time
    logger.info(f"Added {num_vectors} vectors in {add_time:.4f}s")
    
    # Test search performance
    num_searches = 100
    logger.info(f"\nPerforming {num_searches} searches...")
    search_times = []
    
    for _ in range(num_searches):
        query_text = random.choice(texts)
        query_vector = vectorizer.embed(query_text)
        
        start_time = time.time()
        results = storage.search(query_vector, top_k=5)
        search_time = time.time() - start_time
        search_times.append(search_time)
    
    avg_search_time = np.mean(search_times)
    p50_time = np.percentile(search_times, 50)
    p95_time = np.percentile(search_times, 95)
    
    logger.info(f"Average search time: {avg_search_time * 1000:.4f}ms")
    logger.info(f"P50 search time: {p50_time * 1000:.4f}ms")
    logger.info(f"P95 search time: {p95_time * 1000:.4f}ms")
    
    # Check if P95 is under 100ms target
    target = 0.1  # 100ms
    if p95_time < target:
        logger.info("✓ P95 search time meets target (< 100ms)")
    else:
        logger.warning(f"✗ P95 search time exceeds target: {p95_time * 1000:.4f}ms")
    
    return avg_search_time, p50_time, p95_time


def main():
    try:
        test_embedding_performance()
        test_semantic_cache()
        test_vector_search_performance()
        
        logger = setup_logger(level="INFO")
        logger.info("\n" + "=" * 60)
        logger.info("All tests completed successfully!")
        logger.info("=" * 60)
        
    except Exception as e:
        logger = setup_logger(level="ERROR")
        logger.error(f"Error during tests: {e}")
        import traceback
        logger.error(traceback.format_exc())


if __name__ == "__main__":
    main()
